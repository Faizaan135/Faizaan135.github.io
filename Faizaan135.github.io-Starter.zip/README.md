# ABBAS Engineering — Portfolio Site

Static, dependency-free portfolio for the **`Faizaan135.github.io`** repository.

## Publication
1. Create a **public** repository named exactly `Faizaan135.github.io` on the GitHub account `Faizaan135`.
2. Upload the contents of this folder into the repository root (not the parent ZIP folder).
3. On GitHub, open **Settings → Pages**. Under **Build and deployment**, select **Deploy from a branch**, `main`, `/(root)`, then **Save**.
4. Use the Pages settings screen to verify the actual live URL. Do not link an assumed URL as live until deployment has succeeded.

No React, build system, or external runtime dependencies are required. Verify text and public disclosure before publishing.

## Editorial rules
- Don't publish internal Drive or Notion URLs (they may be private).
- Do not claim an AE-001 prototype or measurements exist before validation.
- Review any future photos, schematics, serial numbers, personal details, costs and client material before making them public.

## Local preview
Open `index.html` in a browser. The styles are relative to the site root.
